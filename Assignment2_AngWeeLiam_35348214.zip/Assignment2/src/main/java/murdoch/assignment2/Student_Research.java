
package murdoch.assignment2;

//Student_Research as derived class and Student as base class
public class Student_Research extends Student{
        
        private Research thesis; //to store thesis as Research class
        
        //default constructor
        public Student_Research()
        {
                super(); //calling superclass default constructor
                thesis = new Research(); //initialize thesis as Research with default constructor
        }
        
        //constructor with parameter
        public Student_Research(String initFName, String initGName, long initID, Research object)
        {
                super(initFName, initGName, initID); //set parameter value as superclass constructor parameter
                thesis = object; //set parameter value as thesis
        }
        
        //get methods for thesis
        public Research getResearch()
        {
                return thesis; //return thesis as Research type
        }
        
        //set methods for thesis
        public void setResearch(Research object)
        {
                thesis = object; //set parameter value as thesis
        }
        
        //report grade method
        public String reportGrade()
        {
                return (thesis.getEnrollType() + ", " + getFirstName()+ ", " + getGivenName() + ", " + getStudentID() + 
                        ", " +  thesis.calculateOverallMark() + ", " + thesis.calculateGrade());
        }
}
