
package murdoch.assignment2;

//base class
public class Student {
        
        private String firstName; //to store first name
        private String givenName; //to store given name
        private long studentID; //to store student ID
        
        //default constructors
        public Student()
        {
                firstName = "no name yet"; //default value for first name
                givenName = "no name yet"; //default value for given name
                studentID = 0; //default value for student ID 
        }
        
        //constructor with parameter
        public Student(String initFName, String initGName, long initID)
        {
                firstName = initFName; //store parameter value as first name
                givenName = initGName; //store parameter value as given name
                studentID = initID; //store parameter value as student ID 
        }
        
        //get method for first name
        public String getFirstName()
        {
                return firstName; //return firstName as String type
        }
        
        //get method for given name
        public String getGivenName()
        {
                return givenName; //return givenName as String type
        }
        
        //get method for student ID
        public long getStudentID()
        {
                return studentID; //return studentID as long type
        }
        
        //set method for first name
        public void setFirstName(String initFName)
        {
                firstName = initFName; //set given parameter as firstName
        }
        
        //set method for given name
        public void setGivenName(String initGName)
        {
                givenName = initGName; //set given parameter as givenName 
        }
        
        //set method for student ID
        public void setStudentID(long initID)
        {
                studentID = initID; //set given parameter as student ID 
        }
        
        //report grade method
        public String reportGrade()
        {
               return "There is no grade here."; //default value for reportGrade method, will get override in derived class
        }
        
        //equals method
        public boolean equals(Student object)
        {
                return this.studentID == object.getStudentID(); //equals methods for Student class
        }
        
}

