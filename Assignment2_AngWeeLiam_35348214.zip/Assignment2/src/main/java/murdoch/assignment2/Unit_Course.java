
package murdoch.assignment2;

//Unit_Course as derived class with Unit as base class
public class Unit_Course extends Unit {
        
        private String unitID; //to store unit ID
        private int unitLevel; //to store unit level
        private int [] mark; //to store mark in array
        private int finalMark; //to store final mark 
        
        //default constructor
        public Unit_Course()
        {
                super("C"); //default parameter for superclass constructor
                unitID = "no id yet"; //default value for unitID
                unitLevel = 0; //default value for unitLevel
                mark = new int[4]; //define size of mark array
                for(int counter = 0; counter < mark.length; counter++)
                {
                        mark[counter] = 0; //set default value for mark array
                }
                finalMark = 0; //default value for final mark
        }
        
        //contructor with parameter
        public Unit_Course(String initEnrollType, String initID, int initLevel, int [] initMark, int initFMark)
        {
                super(initEnrollType); //set parameter as superclass constructor 
                unitID = initID; //set parameter as unitID
                unitLevel = initLevel; //set parameter as unitLevel
                mark = initMark; //set parameter as mark array
                finalMark = initFMark; //set parameter as final mark
        }
        
        //get method for unit ID
        public String getUnitID()
        {
                return unitID; //return unitID as String
        }
        
        //get metod for unit level
        public int getUnitLevel()
        {
                return unitLevel; //return unitLevel as integer
        }
        
        //get method for mark
        public int [] getMarks()
        {
                return mark; //return assignment marks as integer array
        }
        
        //get method for final mark
        public int getFinalMark()
        {
                return finalMark; //return final mark as integer
        }
        
        //set method for unit level
        public void setUnitLevel(int initLevel)
        {
                unitLevel = initLevel; //set paramter value as unitLevel
        }
        
        //set method for marks
        public void setMarks(int [] initMarks)
        {
                mark = initMarks; //set parameter value as mark array
        }
        
        //set method for final marks
        public void setFinalMark(int initFMark)
        {
                finalMark = initFMark; //set parameter value as final mark
        }
        
        //calculate overall mark
        public double calculateOverallMark()
        {
                int total = 0; //to store assginment marks
                for(int counter = 0; counter < mark.length; counter++) //perform loop to add assignment mark into total
                {
                        total = total + mark[counter];
                }
                double mark1 = (double) total/400 * 60; //calculate assginment mark
                double mark2 = (double) finalMark/100 * 40; //calculate final mark
                return mark1 + mark2 ; //add up both assignment marks and final mark
        }
        
        //calculate final grade
        public String calculateGrade()
        {
                double overallMark = calculateOverallMark(); //assign overallmark
                return calculateGrade(overallMark); //calculate grade using overallmark
        }
}
