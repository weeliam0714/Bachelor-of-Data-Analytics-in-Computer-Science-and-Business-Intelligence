
package murdoch.assignment2;

//Student_Course as derived class, and Student as base class
public class Student_Course extends Student{
        
        private Unit_Course course; //to store course as Unit_Course type
        
        //default constructor
        public Student_Course()
        {
                super(); //calling superclasss default constructor
                course = new Unit_Course(); //initialize course as Unit_Course with default constructor
        }
        
        //constructor with parameter
        public Student_Course(String initFName, String initGName, long initID,
                String initUnitID,  Unit_Course object)
        {
                super(initFName, initGName, initID); // set parameter as super class constructor parameter
                course = object; //set parameter value as course
        }
        
        //getter methods for unit course
        public Unit_Course getUnitCourse()
        {
                return course; //return course as Unit_Course type
        }
        
        //setter methods for unit course
        public void setUnitCourse(Unit_Course object)
        {
                course = object; //sett parameter as course 
        }
        
        //report grade 
        public String reportGrade()
        {
                return (course.getEnrollType() + ", " + getFirstName()+ ", " + getGivenName() + ", " + getStudentID() + 
                        ", " + course.getUnitID() + ", " + course.calculateOverallMark() + ", " + course.calculateGrade());
        }
        
}
