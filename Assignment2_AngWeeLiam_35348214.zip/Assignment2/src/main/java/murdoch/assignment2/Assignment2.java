
package murdoch.assignment2;
/**
 * Title: Assignment Two
 * Name: Ang Wee Liam
 * ID: 35348214
 * Date: 24/03/2025
 * File name: Principle of Computer Science Assignment 2
 * Purpose: Demonstration of inheritance feature in Java programming and the association between classes.
 * 
 * Input assumptions:
 *      1. A formatted csv file is ready to read by the program. 
 *      2. There are only two type of students, course work students and research students. 
 *      3. The order of details inside the csv file for course work students  must be as follow:
 *              a. enroll type
 *              b. first name
 *              c. given name
 *              d. student ID
 *              e. unit ID
 *              f. unit level
 *              g. mark for assigment 1
 *              h. mark for assigment 2
 *              i. mark for assigment 3
 *              j. mark for assigment 4
 *              k. mark for final exam
 *      4. The order of details inside the csv file for research students  must be as follow:
 *              a. enroll type
 *              b. first name
 *              c. given name
 *              d. student ID
 *              e. mark for proposal 
 *              f. mark for final exam
 *      5. User are expected to key in only integer for the menu selection input.
 * 
 * Output assumptions:
 *      1. Program read the formatted csv file successfully without errors.
 *      2. Program read and store the student details from the csv file successfully.
 *      3. Error message printed when there is no student ID found in the ArrayList.
 *      4. Details of students stored correctly inside the ArrayList. 
 * 
 * Menu selection:
 *      1. Exit program.
 *      2. Remove students details.
 *      3. Print student list details.
 *      4. Print average overall mark.
 *      5. Report student grade. 
 *      6. Sort student list.
 *      7. Write student list to file.
 */

import java.util.*;
import java.io.*;

public class Assignment2 {

    //main method
    public static void main(String[] args)
    {
            //declare variables
            Scanner kb = new Scanner(System.in); //scanner function for keyboard input
            ArrayList<Student> students = new ArrayList<Student>(); //an arraylist to store students details
            String iFileName = "student.csv"; //file name for input file
            String oFileName = "sorted_student.csv"; //file name for output file
            
            //print out my student details
            StudentInfo(); 
            
            //read student details from file and store it in arraylist
            readFile(students, iFileName);
            
            //print menu for user
            int selection; //to store user selection input
            do 
            {
                    printMenu(); //print menu list
                    System.out.println("\nPlease enter a selection: ");
                    selection = kb.nextInt(); //prompt user selection input
                    switchCase(students, selection, oFileName); //perform switch case 
            }
            while(selection != 1); //continue the loop while selection != 1
            
    }
    
    
    //========================END OF MAIN METHOD===============================
    
    
    //methods for student info
    public static void StudentInfo()
        {
                System.out.println("Student Name: Ang Wee Liam ");
                System.out.println("Student Number: 35348214");
                System.out.println("Mode of enrolment: Part-time");
                System.out.println("Tutor name: Mr Jai Lakhyani");
                System.out.println("Tutorial day: Monday");
                System.out.println("Tutorial time: 1830hr");
        }
    
    //methods for read file
    public static void readFile(ArrayList<Student> object, String fileName)
    {
            Scanner iStream = null; //define input stream as null first
            try 
            {
                    iStream = new Scanner(new File(fileName)); //initialize input stream with file name given
                    storeStudentDetails(object, fileName); //store student details into given ArrayList
                    System.out.println("\nFile " + fileName + " read successfully");
                    iStream.close(); //close input stream
            } 
            catch (FileNotFoundException e) //to catch exception in opening file
            {
                    System.out.println("Error opening file: " + fileName); //print error message
                    System.exit(0); //exit system if error occur
            }
    }
    
    
    //methods for storing course work and research student details
    public static void storeStudentDetails(ArrayList<Student> object, String fileName)
    {
            Scanner iStream = null; //define input stream as null first
            try 
            {
                    iStream = new Scanner(new File(fileName)); //initalize input stream with file name given
                    while(iStream.hasNextLine()) //while input stream getting next line
                    {
                            String line = iStream.nextLine(); //assign that read line into line
                            StringTokenizer token = new StringTokenizer(line, ","); //separate the given line into token 
                            String enrollType = token.nextToken(); //set first token as enrollType
                            if(enrollType.equalsIgnoreCase("C")) //if first token is "C"
                            {
                                    String firstName = token.nextToken(); //store as first name
                                    String lastName = token.nextToken(); //store as given name
                                    long studentID = Long.parseLong(token.nextToken()); //parse into long type and store it
                                    String unitID = token.nextToken(); //store as unitID 
                                    int unitLevel = Integer.parseInt(token.nextToken()); //parse into integer type and store it
                                    int[] mark = new int[4]; //define mark array of size 4
                                    for(int counter = 0; counter < 4; counter++) //perform for-loop to store mark
                                    {
                                            mark[counter] = Integer.parseInt(token.nextToken());
                                    }
                                    int finalMark = Integer.parseInt(token.nextToken()); //store final token as final mark
                                    
                                    Unit_Course course = new Unit_Course(enrollType, unitID, unitLevel, mark, finalMark); 
                                    Student student = new Student_Course(firstName, lastName, studentID, unitID, course);
                                    
                                    object.add(student); //add student into our ArrayList
                            }
                            else if(enrollType.equalsIgnoreCase("R")) //if first token is "R"
                            {
                                    String firstName = token.nextToken(); //store as first name
                                    String lastName = token.nextToken(); //store as given name
                                    long studentID = Long.parseLong(token.nextToken()); //parse into long type and store it
                                    int proposalMark = Integer.parseInt(token.nextToken()); //parse into integer type and store it
                                    int finalMark = Integer.parseInt(token.nextToken()); //parse into integer type and store it
                                    
                                    Research thesis = new Research(enrollType, proposalMark, finalMark);
                                    Student_Research student = new Student_Research(firstName, lastName, studentID, thesis);
                                    
                                    object.add(student); //add student into our ArrayList
                            }
                    }
                    iStream.close(); //close input stream
            } 
            catch (FileNotFoundException e)  //catch file not found exception
            {
                    System.out.println("Error opening file: " + fileName); //print error message if file not found
                    System.exit(0); //exit system if error occur
            }
    }
    
    
    //methods for print menu list
    public static void printMenu()
    {
            System.out.println("\nMenu:");
            System.out.println("=====");
            System.out.println("1. Exit program.");
            System.out.println("2. Remove student details.");
            System.out.println("3. Print student list details.");
            System.out.println("4. Print average overall mark.");
            System.out.println("5. Report student grade.");
            System.out.println("6. Sort student list.");
            System.out.println("7. Write student list to file.");
    }
    
    
    //methods for menu selection switch case
    public static void switchCase(ArrayList<Student> object,  int selection, String fileName)
    {
            switch (selection) 
            {
                    case 1:
                            menuSelection1(); //perform method 1
                            break;
                    case 2:
                            menuSelection2(object); //perform method 2
                            break;
                    case 3:
                            menuSelection3(object); //perform method 3
                            break;
                    case 4:
                            menuSelection4(object); //perform method 4
                            break;
                    case 5: 
                            menuSelection5(object); //perform method 5
                            break;
                    case 6:
                            menuSelection6(object); //perform method 6
                            break;
                    case 7:
                            menuSelection7(object, fileName); //perform method 7
                            break;
                    default: 
                    {
                            System.out.println("Invalid selection."); //error message when selection is not 1 - 7
                            System.out.println("Please enter selection 1-7."); //advise user to choose between 1 - 7
                    }
            }
    }
    
    
    //====================START OF MENU SELECTION METHOD 1 - 7=======================
    
    
    //methods for menu selection 1
    public static void menuSelection1()
    {
            System.out.println("\nExiting the program...");
            System.out.println("Program exit successfully!");
            System.exit(0); //exit program
    }
    
    
    //methods for menu selection 2
    public static void menuSelection2(ArrayList<Student> object)
    {
            Scanner kb = new Scanner(System.in); //define scanner as system input
            System.out.println(""); //print blank line
            
            for(Student student : object) //loop through element in object Student
                        System.out.println("Name: " + student.getFirstName() + ", " + student.getGivenName() + 
                                ", ID: " + student.getStudentID()); //print list of student  name and ID
            
            System.out.println("Please enter student ID that you wish to remove:"); //prompt message for student ID
            long studentID = kb.nextLong(); //get user input for student ID to be remove
            boolean found = false; //intial state
            for(int counter = 0; counter < object.size(); counter++)
            {
                    if(object.get(counter).getStudentID() == studentID) //if object studentID same as studentID given by user
                    {
                            found = true; //found become true
                            System.out.println("The following student will get remove from the list.");
                            System.out.println("Name: " + object.get(counter).getFirstName() + ", " + 
                                    object.get(counter).getGivenName() + " ID: " + object.get(counter).getStudentID()); //print student name
                            System.out.println("Do you confirm? (yes/no)"); //reconfirm again
                            String answer = kb.next(); //get user input for answer
                            if(answer.equalsIgnoreCase("yes"))
                            {
                                    System.out.println("Successfully removed " + object.get(counter).getFirstName() + " "+ 
                                            object.get(counter).getGivenName() + ", ID: " + object.get(counter).getStudentID());
                                    object.remove(counter); //remove specific student from list
                                    break;
                            }
                            else
                                    break; //break the loop if answer not 'yes'
                    }                    
            }//end of for loop
            if(found == false) //if found remain false
                    System.out.println("No matched student ID found in the list."); //print error message
    }
    
    
    //methods for menu selection 3
    public static void menuSelection3(ArrayList<Student> object)
    {
            System.out.println("\nStudent List Details:"); //print message header
            for(Student student : object) //loop through object element 
                    System.out.println(student.reportGrade()); //report grade for each students
    }
    
    
    //methods for menu selection 4
    public static void menuSelection4(ArrayList<Student> object)
    {
            double total = 0; //to store total
            int len = 0; //to store number of Student_Course in the object
            int above = 0; //to store total number of mark above or equal to average mark
            int below = 0; //to store total number of mark below average mark
            double average; //to store average mark
            for(Student student : object) //loop through ArrayList
            {
                    if(student instanceof Student_Course) //if element is instance of type Student_Course
                    {
                            total = total + ((Student_Course) student).getUnitCourse().calculateOverallMark(); //add mark into total
                            len++; //increment size of student_course
                    }
            }
            average = total / len; //calculate average of student_course mark
            System.out.println(""); //print blank line
            for(Student student : object) //loop through ArrayList
            {
                    if(student instanceof Student_Course) //if element is instance of type Student_Course
                    {
                            if(((Student_Course) student).getUnitCourse().calculateOverallMark() >= average) 
                                    above++; //increment 'above' if mark is above or equal to average mark
                            else
                                    below++; //increment 'below' if mark is below average mark 
                            
                            System.out.println(student.reportGrade()); //print student details
                    }
            }
            System.out.println("Average overall mark for course work students: " + average); //print average mark
            System.out.println("Number of student ABOVE or EQUAL to average overall mark: " + above); //print number of above
            System.out.println("Number of student BELOW average overall mark: " + below); //print number of below
            
    }
    
    
    //methods for menu selection 5
    public static void menuSelection5(ArrayList<Student> object)
    {
            Scanner kb = new Scanner(System.in); //define keyboard input
            System.out.println(""); //print blank line
            for(Student student : object) //loop through ArrayList
                        System.out.println("Name: " + student.getFirstName() + ", " + student.getGivenName() + ", ID: " + 
                                student.getStudentID()); //print student details
            
            System.out.println("Please enter a student ID to report their grade:"); //prompt message for student ID
            long studentID = kb.nextLong(); //get user input for student ID 
            boolean found = false; //initial state
            for(Student student : object) //loop through ArrayList
            {
                    if(student.getStudentID() == studentID) //if student ID found 
                    {
                            System.out.println(""); //print blank line
                            System.out.println(student.reportGrade()); //report student grade
                            found = true; //'found' become true
                            break;
                    } 
            } 
            if(found == false) //if found is still false after the loop
                    System.out.println("\nStudent ID not found in the list."); //print not found message
    }
    
    
    //methods for menu selection 6
    public static void menuSelection6(ArrayList<Student> object)
    {
            System.out.println("\nSorted student list:"); //print header message
            for(int counter1 = 1; counter1 < object.size(); counter1++) //for-loop insertion sort
            {
                    Student temp = object.get(counter1); //assign index 1 into temp
                    long tempID = object.get(counter1).getStudentID(); //assign index 1 studentID into tempID
                    
                    int counter2 = counter1 - 1; //set second counter as counter1 - 1
                    
                    while(counter2 >= 0 && object.get(counter2).getStudentID() > tempID) //while counter2 more than 0 or value more than tempID
                    {
                            object.set(counter2 + 1, object.get(counter2)); //shift counter2 value to right
                            counter2--; //decrement counter2
                    }
                    object.set(counter2 + 1, temp); //assign temp to the opening
            }
            
            for(Student student : object) //loop through ArrayList
                    System.out.println(student.reportGrade()); //report student grade
    }
    
    
    //methods for menu selection 7
    public static void menuSelection7(ArrayList<Student> object, String fileName)
    {
            boolean notSorted = false; //initial state
            for(int counter = 0; counter < object.size() - 1; counter++) //for-loop to check the ArrayList is sorted
            {
                    for(int counter2 = counter; counter2 < object.size(); counter2++)
                    {
                            if(object.get(counter).getStudentID() > object.get(counter2).getStudentID()) //if element at left bigger than element on the right
                            {
                                    System.out.println("\nStudent list is not sorted yet."); //print not sorted message
                                    System.out.println("Please sort it first (option 6), before selecting this option."); //prompt user to sort 
                                    notSorted = true; //notSorted become true
                                    break; //break inner loop
                            }
                    } 
                    if(notSorted == true) 
                            break; //break outer loop
            }
            if(notSorted == false)
                 writeFile(object, fileName); //write to file if the ArrayList pass the checking
    }
    
    
    //methods for write to file
    public static void writeFile(ArrayList<Student> object, String fileName)
    {
            PrintWriter oStream = null; //define output stream as null first
            try 
            {
                    oStream = new PrintWriter(new File(fileName)); //initalize output stream with given file name
                    
                    for(Student student : object) //loop through ArrayList
                    {
                            oStream.println(student.reportGrade()); //write to file with student reportGrade
                    }
                    System.out.println("\nData successfully write to file: " + fileName); //print sucess message after write to file
                    oStream.close(); //close output stream
            } 
            catch (FileNotFoundException e) //catch file not found exception
            {
                    System.out.println("Error print to file: " + fileName); //print error message when file not found
                    System.exit(0); //exit program if error occur
            }
    }
}

