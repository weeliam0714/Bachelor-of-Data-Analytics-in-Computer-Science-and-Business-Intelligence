
package murdoch.assignment2;

//Research as the derived class and Unit as the base class
public class Research extends Unit{
        
        private int proposalMark; //to store proposal mark
        private int finalMark; //to store final mark 
        
        //default constructor
        public Research()
        {
                super("R"); //default parameter for super class constructor
                proposalMark = 0; //default value for proposal mark
                finalMark = 0; //default value for final mark
        }
        
        //constructor with parameter
        public Research(String initEnrollType, int initPMark, int initFMark)
        {
                super(initEnrollType); //set parameter as superclass constructor 
                proposalMark = initPMark; //set parameter value as proposal mark
                finalMark = initFMark; //set parameter value as final mark
        }
        
        //get method for proposal mark
        public int getProposalMark()
        {
                return proposalMark; //return proposal mark as interger
        }
        
        //get method for final mark
        public int getFinalMark()
        {
                return finalMark; //return final mark as integer
        }
        
        //set method for proposal mark
        public void setProposalMark(int initPMark)
        {
                proposalMark = initPMark; //set parameter value as proposal mark
        }
        
        //set method for final mark
        public void setFMark(int initFMark)
        {
                finalMark = initFMark; //set parameter value as final mark
        }
        
        //calculate overall mark
        public double calculateOverallMark()
        {
                double mark1 = (double) proposalMark/100 * 40; //calculate proposal mark
                double mark2 = (double) finalMark/100 * 60; //calculate final mark
                return mark1 + mark2; //add proposal mark and final mark and return it as double
        }
        
        //calculate final grade
        public String calculateGrade()
        {
                double overallMark = calculateOverallMark(); //assign overallmark
                return calculateGrade(overallMark); //calculate grade using overallmark
        }
}
