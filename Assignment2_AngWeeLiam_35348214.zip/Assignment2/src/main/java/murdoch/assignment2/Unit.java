
package murdoch.assignment2;

//base class
public class Unit {
        
        private String enrollType; //to store enroll type
        
        //default contructor
        public Unit()
        {
                enrollType = "no enroll type yet"; //default value for enroll type
        }
        
        //constructor with parameter
        public Unit(String initEnrollType)
        {
                enrollType = initEnrollType; //to store parameter value as enroll type
        }
        
        //get method for enroll type
        public String getEnrollType()
        {
                return enrollType; //return enrollType as String
        }
        
        //set method for enroll type
        public void setEnrollType(String initEnrollType)
        {
                enrollType = initEnrollType; //set parameter as enroll type
        }
        
        //calculate final grade methods
        public String calculateGrade(double overallMark)
        {
                if(overallMark >= 80 && overallMark <= 100) //if mark between 80 - 100 inclusively
                        return "HD";
                else if(overallMark >= 70 && overallMark < 80) //if mark between 70  - 79 inclusively
                        return "D";
                else if(overallMark >= 60 && overallMark < 70) //if mark between 60 - 69 inclusively
                        return "C";
                else if(overallMark >= 50 && overallMark < 60) //if mark between 50 - 59 inclusively
                        return "P";
                else if(overallMark >= 0 && overallMark < 50  ) //if mark between 0 - 49 inclusively
                        return "N";
                else
                        return "Invalid Mark!"; // if out of range 0 - 100
        }
}
