
package com.mycompany.assignment1;

/**
 * Title: Assignment One
 * Name: Ang Wee Liam
 * ID: 35348214
 * Date: 24/02/2025
 * File name: Principle of Computer Science Assignment 1
 * Purpose: Demonstration of coin change function
 * User guide: 
 *      1. Uncomment the testMethod(client, counter), if you wish to skip the data entry part. 
 *      2. Uncomment the manualMethod(client, counter), if you wish to enter data manually.
 * Pre-condtion: 
 *      1. Person name must be one-word string. 
 *      2. Coin amount must be multiples of 5, range between 5-1000 inclusively.
 *      3. Menu options must be range 1-6. 
 * Post-condition:
 *      1. Choose a selection from the Menu list. 
 *      2. Enter a name you wish to search for after you selected Menu option 1.
 *      2. Select option 6 to exit the program.
 *      3. Else, select any option from 1-5. 
 * Menu selection:
 *      1. Print the name of person and coin change amount.
 *      2. Print the person with the smallest coin amount from the array.
 *      3. Print the person with the largest coin amount from the array.
 *      4. Print the total sum of each denominations.
 *      5. Print the total sum of coin amount. 
 *      6. Exit the program.
 */

import java.util.Scanner; //import java scanner 
import java.util.Set;
public class Assignment1 
{
        //MAIN METHOD
        public static void main(String[] args) 
        {
                //DECLARE VARIABLES
                Scanner kb = new Scanner(System.in);
                ChangeC[] client = new ChangeC[10];
                int counter = 0;

                //INITIALIZE ARRAY
                initObject(client);
                
                //STUDENT INFO
                StudentInfo();
                
                //print start message  
                System.out.println("\nRecommendation: Please enter at least 10 records to test the program.");
                
                //TEST METHOD (UNCOMMENT THE LINE BELOW TO RUN THE METHOD)
                testMethod(client, counter);
                
                //MANUAL METHOD (UNCOMMENT THE LINE BELOW TO RUN THE METHOD)
                //manualMethod(client, counter);

                //SWITCH CASE MENU LOOP
                int selection; //to store switch case choice
                do 
                {
                        printMenu(); //print menu
                        selection = kb.nextInt(); //get user input for switch case choice
                        switchCase(client, selection); //switch case
                } 
                while (selection != 6);
        }
    
        
        
       /*
        =========================END OF MAIN METHOD=============================
        ========================START OF OTHER METHODS============================
        */
        
        
        
        //TEST METHOD (HARD CODED)
        //===================
        public static void testMethod(ChangeC[] object, int counter)
        {
                //DECLARE VARIABLES
                String[] name = {"Bob", "Jane", "William", "Jasmin", "Willy", "John", "Smith", "Wayne", "Lily", "Charlie"};
                int[] amount = {100, 200, 300, 400, 500, 600, 700, 800, 900, 1000};
                
                //ASSIGN HARD CODED VALUE INTO THE OBJECT
                for(counter = 0; counter < object.length; counter++)
                {
                        object[counter] = new ChangeC();
                        object[counter].setName(name[counter]);
                        object[counter].setAmount(amount[counter]);
                        System.out.println("#" + (counter + 1) + " Name: " + object[counter].getName());
                        System.out.println("#" + (counter + 1) + " Amount: " + object[counter].getAmount());
                        System.out.println("");
                }
        }
        
        //MANUAL METHOD (TO MANUALLY ENTER THE DATA)
        //==================================
        public static void manualMethod(ChangeC[] object, int counter)
        {
                int answer;
                do
                {
                        getNameInput(object, counter); //get input for object name
                        getAmountInput(object, counter); //get input for object amount
                        answer = askForMore(); //ask for more people
                        counter++; //counter increment
                }
                while(counter < object.length && answer == 'Y');
        }
        
        //METHOD TO INITIALIZE OBJECT
        //====================
        public static void initObject(ChangeC[] object)
        {
                for(int counter = 0; counter < object.length; counter++)
                {
                        object[counter] = new ChangeC();
                }
        }
        
        //METHOD TO PRINT STUDENT INFO
        public static void StudentInfo()
        {
                System.out.println("Student Name: Ang Wee Liam ");
                System.out.println("Student Number: 35348214");
                System.out.println("Mode of enrolment: Part-time");
                System.out.println("Tutor name: Mr Jai Lakhyani");
                System.out.println("Tutorial day: Monday");
                System.out.println("Tutorial time: 1830hr");
        }
        
        //METHOD TO GET USER INPUT FOR OBJECT NAME
        //===============================
        public static void getNameInput(ChangeC[] object, int counter)
        {
                Scanner kb = new Scanner(System.in);
                boolean duplicate = false;
                do 
                {
                        System.out.println("Please enter the name of the #" + (counter + 1) + " person:");
                        object[counter].setName(kb.next());

                        for(int inner = 0; inner < counter; inner++)
                        {
                                if(object[counter].getName().equalsIgnoreCase(object[inner].getName()))
                                {
                                        System.out.println("Error: Name is duplicated.");
                                        System.out.println("Please enter a different name.");
                                        duplicate = true;
                                        break;
                                }
                                else
                                {
                                        duplicate = false;
                                }
                        }
                }
                while (duplicate);
        }
        
        //METHOD TO GET USER OBJECT AMOUNT
        //==========================
        public static void getAmountInput(ChangeC[] object, int counter)
        {
                Scanner kb = new Scanner(System.in);
                do 
                {
                        System.out.println("Please enter the coin value for the #" + (counter  + 1) + " person:");
                        object[counter].setAmount(kb.nextInt());

                } 
                while (object[counter].getAmount() % 5 != 0 || object[counter].getAmount() < 5 || object[counter].getAmount() > 1000 );
        }
        
        //METHOD TO ASK FOR MORE PEOPLE
        //=======================
        public static char askForMore()
        {
                char answer;
                Scanner kb = new Scanner(System.in);
                
                do
                {
                        System.out.println("Do you have more person to enter (Y/N): ");
                        answer = kb.next().trim().toUpperCase().charAt(0);

                        //CHECK ANSWER 
                        if(answer != 'N' && answer != 'Y')
                        {
                                System.out.println("Error: Please enter  'Y' or 'N'.");
                                System.out.println("Please re-enter your answer.");
                        }
                }
                while(answer != 'N' && answer != 'Y');
                return answer;
        }
        
        
        //METHOD TO PRINT MENU
        //=================
        public static void printMenu()
        {
                System.out.println("\nMenu");
                System.out.println("==================");
                System.out.println("1. Display name and change");
                System.out.println("2. Display smallest amount and change.");
                System.out.println("3. Display largest amount and change.");
                System.out.println("4. Display total number of currency note.");
                System.out.println("5. Display the total amount for the sum of all denominations.");
                System.out.println("6. Exit.");
                System.out.println("Your selection: ");
        }
        
        //METHOD TO PRINT CUSTOMER NAME AND AMOUNT
        //==================================
        public static void printNameAmount(ChangeC[] object, int counter)
        {
                System.out.println("Customer: ");
                System.out.println(object[counter].getName() + " $" + object[counter].getAmount());
        }
        
        //METHOD TO PRINT NOTE CHANGE AMOUNT
        //=============================
        public static void printNoteChange(ChangeC[] object, int counter)
        {
                //print currency note change
                System.out.println("Change: ");
                if(object[counter].getNote1000() > 0)
                {
                        System.out.println("Note 1000: " + object[counter].getNote1000());
                }
                if(object[counter].getNote500() > 0)
                {
                        System.out.println("Note 500: " + object[counter].getNote500());
                }
                if(object[counter].getNote200() > 0)
                {
                        System.out.println("Note 200: " + object[counter].getNote200());
                }
                if(object[counter].getNote100() > 0)
                {
                        System.out.println("Note 100: " + object[counter].getNote100());
                }
                if(object[counter].getNote50() > 0)
                {
                        System.out.println("Note 50: " + object[counter].getNote50());
                }
                if(object[counter].getNote20() > 0)
                {
                        System.out.println("Note 20: " + object[counter].getNote20());
                }
                if(object[counter].getNote10() > 0)
                {
                        System.out.println("Note 10: " + object[counter].getNote10());
                }
                if(object[counter].getNote5() > 0)
                {
                        System.out.println("Note 5: " + object[counter].getNote5());
                }
        }
        
        //METHOD FOR SWITCH CASE
        //==================
        public static void switchCase(ChangeC[] object, int num)
        {
                 switch (num) 
                        {
                                case 1:
                                {
                                        selectionOne(object);
                                        break;
                                }
                                case 2:
                                {
                                        selectionTwo(object);
                                        break;
                                }
                                case 3:
                                {
                                        selectionThree(object);
                                        break;
                                }
                                case 4:
                                {
                                        selectionFour(object);
                                        break;
                                }
                                case 5:
                                {
                                        selectionFive(object);
                                        break;
                                }
                                case 6:
                                {
                                        System.out.println("Exiting program...");
                                        System.out.println("Program exit successfully!");
                                        break;
                                }
                                default:
                                {
                                        System.out.println("Error: Invalid input!");
                                        System.out.println("Please enter selection 1-6.");
                                }
                        }
        }
        
        
        
        /*
        =====================END OF OTHER METHODS===============================
        =====================START OF SWITCH CASE METHODS==========================
        */
        
        
        
        //SWITCH CASE SELECTION 1
        //==================
        public static void selectionOne(ChangeC[] object)
        {
                Scanner kb = new Scanner(System.in);
                System.out.println("Enter a name:");
                String name = kb.next().trim();
                boolean notFound = true;
                for(int counter = 0; counter < object.length; counter++)
                {
                        if(object[counter].getName().equalsIgnoreCase(name))
                        {
                                notFound = false;
                                printNameAmount(object, counter);
                                printNoteChange(object, counter);
                        }
                }
                if(notFound)
                {
                        System.out.println("Name: " + name);
                        System.out.println("Not found");
                }
        }
        
        //SWITCH CASE SELECTION 2
        //==================
        public static void selectionTwo(ChangeC[] object)
        {
                int smallest = object[0].getAmount();
                int index = 0;
                int counter;
                for(counter = 0; counter < object.length; counter++)
                {
                        if(smallest > object[counter].getAmount())
                        {
                                smallest = object[counter].getAmount();
                                index = counter;
                        }
                }
                printNameAmount(object, index);
                printNoteChange(object, index);
                
        }
        
        //SWITCH CASE SELECTION 3
        //==================
        public static void selectionThree(ChangeC[] object)
        {
                int largest = object[0].getAmount();
                int index = 0;
                int counter;
                for(counter = 0; counter < object.length; counter++)
                {
                        if(largest < object[counter].getAmount())
                        {
                                largest = object[counter].getAmount();
                                index = counter;
                        }
                }
                printNameAmount(object, index);
                printNoteChange(object, index);
        }
        
        //SWITCH CASE SELECTION 4
        //==================
        public static void selectionFour(ChangeC[] object)
        {
                int note5 = 0;
                int note10 = 0;
                int note20 = 0;
                int note50 = 0;
                int note100 = 0;
                int note200 = 0;
                int note500 = 0;
                int note1000 = 0;
                for(int counter = 0; counter < object.length; counter++)
                {
                        note5 = note5 + object[counter].getNote5();
                        note10 = note10 + object[counter].getNote10();
                        note20 = note20 + object[counter].getNote20();
                        note50 = note50 + object[counter].getNote50();
                        note100 = note100 + object[counter].getNote100();
                        note200 = note200 + object[counter].getNote200();
                        note500 = note500 + object[counter].getNote500();
                        note1000 = note1000 + object[counter].getNote1000();
                }
                System.out.println("Total currency note for each denominations:");
                System.out.println("Note5: " + note5);
                System.out.println("Note10: " + note10);
                System.out.println("Note20: " + note20);
                System.out.println("Note50: " + note50);
                System.out.println("Note100: " + note100);
                System.out.println("Note200: " + note200);
                System.out.println("Note500: " + note500);
                System.out.println("Note1000: " + note1000);
        }
        
        //SWITCH CASE SELECTION 5
        //==================
        public static void selectionFive(ChangeC[] object)
        {
                int amount = 0;
                for(int counter = 0; counter < object.length; counter++)
                {
                        amount = amount + object[counter].getAmount();
                }
                System.out.println("The total amount: $" + amount);
        }
}
