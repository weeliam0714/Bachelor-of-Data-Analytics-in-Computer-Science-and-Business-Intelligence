
package com.mycompany.assignment1;

/**
 * Title: Assignment One
 * Name: Ang Wee Liam
 * ID: 35348214
 */
public class ChangeC 
{
        private String name;
        private int amount;
        private int note5 = 0;
        private int note10 = 0;
        private int note20 = 0;
        private int note50 = 0;
        private int note100 = 0;
        private int note200 = 0;
        private int note500 = 0;
        private int note1000 = 0;
        
        //DEFAULT CONSTRUCTOR
        public ChangeC()
        {
                this.name = "unknown";
                this.amount = 0;
        }
        
        //CONSTRUCTOR WITH TWO PARAMETERS
        public ChangeC(String initialName, int initialAmount)
        {
                this.name = initialName;
                this.amount = initialAmount;
                        
                 if(initialAmount % 5 != 0 || initialAmount < 5 || initialAmount > 1000)
                 {
                         System.out.println("Error: Please enter numbers in multiples of 5 and between 5 and 1000.");
                         System.out.println("Please re-enter your amount.");
                 }
                 else
                 {
                         calculateChangeNote(amount);
                 }
        }
        
        //GET METHOD #1
        public String getName()
        {
                return name;
        }
        
        //GET METHOD #2
        public int getAmount()
        {
                return amount;
        }
        
        //GET METHOD #3
        public int getNote5()
        {
                return note5;
        }
        
        //GET METHOD #4
        public int getNote10()
        {
                return note10;
        }
        
        //GET METHOD #5
        public int getNote20()
        {
                return note20;
        }
        
        //GET METHOD #6
        public int getNote50()
        {
                return note50;
        }
        
        //GET METHOD #7
        public int getNote100()
        {
                return note100;
        }
        
        //GET METHOD #8
        public int getNote200()
        {
                return note200;
        }
        
        //GET METHOD #9
        public int getNote500()
        {
                return note500;
        }
        
        //GET METHOD #10
        public int getNote1000()
        {
                return note1000;
        }
        
        //SET METHOD #1
        public void setName(String initialName)
        {
                name = initialName;
        }
        
        //SET METHOD #2
        public void setAmount(int initialAmount)
        {
                this.amount = initialAmount;
                        
                 if(initialAmount % 5 != 0 || (initialAmount < 5 || initialAmount > 1000))
                 {
                         System.out.println("Error: Please enter numbers in multiples of 5 and between 5 and 1000.");
                         System.out.println("Please re-enter your amount.");
                 }
                 else
                 {
                         calculateChangeNote(amount);
                 }
        }
        
        //SET METHOD #3
        public void setNameAmount(String initialName, int initialAmount)
        {
                name = initialName;
                
                this.amount = initialAmount;
                        
                 if(initialAmount % 5 != 0 || initialAmount < 5 || initialAmount > 1000)
                 {
                        System.out.println("Error: Please enter numbers in multiples of 5 and between 5 and 1000.");
                        System.out.println("Please re-enter your amount.");
                 }
                 else
                 {
                         calculateChangeNote(amount);
                 }
        }
        
        //HELPER METHOD
        //COUNT CHANGE NOTE AMOUNT
        private void calculateChangeNote(int amount)
        {
                int remainder = amount;
                
                if(remainder > 0)
                {
                        note1000 = remainder / 1000;
                        remainder = remainder % 1000;
                        note500 = remainder / 500;
                        remainder = remainder % 500;
                        note200 = remainder / 200;
                        remainder = remainder % 200;
                        note100 = remainder / 100;
                        remainder = remainder % 100;
                        note50 = remainder / 50;
                        remainder = remainder % 50;
                        note20 = remainder / 20;
                        remainder = remainder % 20;
                        note10 = remainder / 10;
                        remainder = remainder % 10;
                        note5 = remainder / 5;
                        remainder = remainder % 5;
                }
        }
        
}
