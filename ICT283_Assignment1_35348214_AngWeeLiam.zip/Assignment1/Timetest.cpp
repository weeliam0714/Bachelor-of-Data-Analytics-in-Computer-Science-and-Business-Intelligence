//TimeTest.cpp

#include "time.h"

#include <iostream>
#include <string.h>

void Test1(Time &T);
void Test2(Time &T);
void Test3(Time &T);
void Test4(Time &T);
void Test5(Time &T);
void Test6(Time &T);
void Test7(Time &T);

int main(){

    Time T;

    Test1(T);
    Test2(T);
    Test3(T);
    Test4(T);
    Test5(T);
    Test6(T);
    Test7(T);
}

void Test1(Time &T){
    std::cout << "Test Method 1: SetHour()\n";
    T.SetHour(13);
    std::cout << "Result: Hour Set Successfully.\n\n";
}

void Test2(Time &T){
    std::cout << "Test Method 2: GetHour()\n";
    std::cout << "Result: " << T.GetHour() << "\n\n";
}

void Test3(Time &T){
    std::cout << "Test Method 3: SetMinute()\n";
    T.SetMinute(50);
    std::cout << "Result: Minute Set Successfully.\n\n";
}

void Test4(Time &T){
    std::cout << "Test Method 4: GetMinute()\n";
    std::cout << "Result: " << T.GetMinute() << "\n\n";
}

void Test5(Time &T){
    std::cout << "Test Method 5: GetTime()\n";
    std::cout << "Result: " << T.GetTime() << "\n\n";
}

void Test6(Time &T){
    std::cout << "Test Method 6: SetTime() again\n";
    T.SetTime(14,55);
    std::cout << "Result: Time Set Successfully.\n\n";
}

void Test7(Time &T){
    std::cout << "Test Method 7: GetTime()\n";
    std::cout << "Result: " << T.GetTime() << "\n\n";
}

void Test8(Time &T){
    std::cout << "Test Method 8: Print out Time.\n";
    std::cout << "Result: "
        << T;
}


