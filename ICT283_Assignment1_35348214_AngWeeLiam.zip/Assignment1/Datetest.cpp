//DateTest.cpp

#include "date.h"

#include <iostream>
#include <string.h>

void Test1(Date &dt);
void Test2(Date &dt);
void Test3(Date &dt);
void Test4(Date &dt);
void Test5(Date &dt);
void Test6(Date &dt);
void Test7(Date &dt);

int main(){

    Date dt;

    Test1(dt);
    Test2(dt);
    Test3(dt);
    Test4(dt);
    Test5(dt);
    Test6(dt);
    Test7(dt);
}

void Test1(Date &dt){
    std::cout << "Test Method 1: SetDay()\n";
    dt.SetDay(1);
    std::cout << "Result: Day Set Successfully.\n\n";
}

void Test2(Date &dt){
    std::cout << "Test Method 2: GetDay()\n";
    std::cout << "Result: " << dt.GetDay() << "\n\n";
}

void Test3(Date &dt){
    std::cout << "Test Method 3: SetMonth()\n";
    dt.SetMonth(1);
    std::cout << "Result: Month Set Successfully.\n\n";
}

void Test4(Date &dt){
    std::cout << "Test Method 4: GetMonth()\n";
    std::cout << "Result: " << dt.GetMonth() << "\n\n";
}

void Test5(Date &dt){
    std::cout << "Test Method 5: SetYear()\n";
    dt.SetYear(2025);
    std::cout << "Result: Year Set Successfully.\n\n";
}

void Test6(Date &dt){
    std::cout << "Test Method 6: GetYear()\n";
    std::cout << "Result: " << dt.GetYear() << "\n\n";
}

void Test7(Date &dt){
    std::cout << "Test Method 7: Print out Date.\n";
    std::cout << "Result: "
        << dt;
}


