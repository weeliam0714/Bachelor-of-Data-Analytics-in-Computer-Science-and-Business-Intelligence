var struct_w_t_s_type =
[
    [ "d", "struct_w_t_s_type.html#aabe7dc8f1ad332a3ec90735fa5eea603", null ],
    [ "speed", "struct_w_t_s_type.html#a117965f52427ff7c83809bd9508b2cf5", null ],
    [ "sunRad", "struct_w_t_s_type.html#a94eb0dde64916a668085bba33f082c61", null ],
    [ "t", "struct_w_t_s_type.html#a616cd3285ff1e842eca3d8d19e3c3503", null ],
    [ "temp", "struct_w_t_s_type.html#ab53d4de57755cd30eb6b4201f8c69b7d", null ]
];