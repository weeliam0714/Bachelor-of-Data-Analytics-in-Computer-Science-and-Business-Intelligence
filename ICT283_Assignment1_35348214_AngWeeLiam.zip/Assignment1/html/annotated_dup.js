var annotated_dup =
[
    [ "Date", "class_date.html", "class_date" ],
    [ "Time", "class_time.html", "class_time" ],
    [ "Vector", "class_vector.html", "class_vector" ],
    [ "WTSType", "struct_w_t_s_type.html", "struct_w_t_s_type" ]
];