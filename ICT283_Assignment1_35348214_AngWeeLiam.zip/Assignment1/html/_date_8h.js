var _date_8h =
[
    [ "Date", "class_date.html", "class_date" ],
    [ "operator<<", "_date_8h.html#a1b0dcfcc21bf11a788f4ee1e0208dfa8", null ],
    [ "operator>>", "_date_8h.html#a92af6f242f9d6bb312aa34db3f594f02", null ]
];