var searchData=
[
  ['file_17',['file',['../_r_e_a_d_m_e_8txt.html#a6a8ecc099df4ae8c54d28d91ef19e793',1,'README.txt']]]
];
