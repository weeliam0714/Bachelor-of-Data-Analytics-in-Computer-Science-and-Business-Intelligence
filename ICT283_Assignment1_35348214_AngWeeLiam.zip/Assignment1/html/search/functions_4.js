var searchData=
[
  ['main_117',['main',['../_datetest_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;Datetest.cpp'],['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;main.cpp'],['../_timetest_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;Timetest.cpp'],['../_vectortest_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;Vectortest.cpp'],['../_r_e_a_d_m_e_8txt.html#a6fcab763d9b0eb9fc1e3a08c8e2f3e3e',1,'main(). main() routine must show the high level algorithm implementation. So the following must be crystal clear in main() input - where it is from processing - high level processing steps(no detail:&#160;README.txt']]]
];
