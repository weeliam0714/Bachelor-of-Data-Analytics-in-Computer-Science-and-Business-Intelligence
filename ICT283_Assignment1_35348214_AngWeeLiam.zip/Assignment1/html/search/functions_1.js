var searchData=
[
  ['calculatemean_104',['calculateMean',['../main_8cpp.html#a8d2f6ecca80e06fca23078db1f4f5042',1,'main.cpp']]],
  ['calculatesd_105',['calculateSD',['../main_8cpp.html#ab80189159a550fabe7f97f613bdd11c4',1,'main.cpp']]],
  ['calculatesum_106',['calculateSum',['../main_8cpp.html#a48512dfc814ac5795106f3e0c20517f5',1,'main.cpp']]]
];
