var searchData=
[
  ['readfile_39',['readFile',['../main_8cpp.html#a2c25b9c218f92f3362f903a1f3bb93c5',1,'main.cpp']]],
  ['readme_2etxt_40',['README.txt',['../_r_e_a_d_m_e_8txt.html',1,'']]]
];
