var _date_8cpp =
[
    [ "operator<<", "_date_8cpp.html#a1b0dcfcc21bf11a788f4ee1e0208dfa8", null ],
    [ "operator>>", "_date_8cpp.html#a92af6f242f9d6bb312aa34db3f594f02", null ]
];