var _time_8cpp =
[
    [ "operator<<", "_time_8cpp.html#ab5620f895d7ad4517b80695864626e90", null ],
    [ "operator>>", "_time_8cpp.html#ae4cca09a1b47d8d7c4e90547fc844f9a", null ]
];