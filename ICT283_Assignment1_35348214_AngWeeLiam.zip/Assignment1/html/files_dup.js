var files_dup =
[
    [ "Assignment 1 Test Plan & Evaluation", "dir_5e82b005cd8c60415927d9722d1b7f56.html", null ],
    [ "Date.cpp", "_date_8cpp.html", "_date_8cpp" ],
    [ "Date.h", "_date_8h.html", "_date_8h" ],
    [ "Datetest.cpp", "_datetest_8cpp.html", "_datetest_8cpp" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Time.cpp", "_time_8cpp.html", "_time_8cpp" ],
    [ "Time.h", "_time_8h.html", "_time_8h" ],
    [ "Timetest.cpp", "_timetest_8cpp.html", "_timetest_8cpp" ],
    [ "Vector.h", "_vector_8h.html", [
      [ "Vector", "class_vector.html", "class_vector" ]
    ] ],
    [ "Vectortest.cpp", "_vectortest_8cpp.html", "_vectortest_8cpp" ]
];