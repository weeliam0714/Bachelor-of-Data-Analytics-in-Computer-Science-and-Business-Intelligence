var _time_8h =
[
    [ "Time", "class_time.html", "class_time" ],
    [ "operator<<", "_time_8h.html#ab5620f895d7ad4517b80695864626e90", null ],
    [ "operator>>", "_time_8h.html#ae4cca09a1b47d8d7c4e90547fc844f9a", null ]
];