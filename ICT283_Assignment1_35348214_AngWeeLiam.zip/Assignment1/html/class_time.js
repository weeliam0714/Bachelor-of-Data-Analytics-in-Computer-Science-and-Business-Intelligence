var class_time =
[
    [ "Time", "class_time.html#a4245e409c7347d1d671858962c2ca3b5", null ],
    [ "Time", "class_time.html#ad41532fa9dca778133707905c27eddc9", null ],
    [ "GetHour", "class_time.html#aa36ebd154ebbc9bba775bcb6b125a8a3", null ],
    [ "GetMinute", "class_time.html#acb63d3fc6457724ce1e54d2b6f212b7f", null ],
    [ "GetTime", "class_time.html#af9c77c144c4c4c1e50b0459325234fc9", null ],
    [ "SetHour", "class_time.html#ab8c6582ad99c617c821ad3d10b9a872e", null ],
    [ "SetMinute", "class_time.html#a08cdbeef8e01ad48aadab6db90665d85", null ],
    [ "SetTime", "class_time.html#adfc4c91f6be528464f935061cbcc1ea7", null ],
    [ "hour", "class_time.html#a497d35aa44ea40706dbab08f7a31d069", null ],
    [ "minute", "class_time.html#a6c2e13147da34803a9784aa2b8bf8da8", null ]
];