#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <cmath>
#include "vector.h"
#include "date.h"
#include "time.h"

//data structure
typedef struct{
    Date d;
    Time t;
    float speed;
    float temp;
    float sunRad;
}WTSType;

//alias definition
typedef Vector<WTSType> WTSlogType; //WTSlogType is a realized Vector Type

//function declaration
void openFile(std::ifstream &infile1, std::ifstream &infile2);
void readFile(std::ifstream &infile, WTSlogType &wts_data);
template <class T> T calculateSum(Vector<T> &vec);
template <class T> T calculateMean(Vector<T> &vec);
template <class T> T calculateSD(Vector<T> &vec);
void printMenu();
void switchCases(WTSlogType &wts_data);
void switchCase1(WTSlogType &wts_data);
void switchCase2(WTSlogType &wts_data);
void switchCase3(WTSlogType &wts_data);
void switchCase4(WTSlogType &wts_data);
void switchCase5(WTSlogType &wts_data);
void defaultSC();

//========================START OF MAIN METHOD===================================
//===============================================================================
//main method

const int N = 10;

int main()
{
    std::ifstream infile1;
    std::ifstream infile2;
    openFile(infile1,infile2); //to read data source file and get the actual data file name

    WTSlogType wts_data(N); //Vector variable called wts_data

    readFile(infile2, wts_data); //read file input

    switchCases(wts_data); //print menu and perform switch cases

    return 0;
}

//==========================END OF MAIN METHOD===================================
//===============================================================================

//To read infile two times
void openFile(std::ifstream &infile1, std::ifstream &infile2){
    std::string filename1 = "data_source.txt"; //file storing the data file name
    std::string filename2; //to store data file name

    infile1.open(filename1); //open the text file to read the name of the data file
    if(!infile1) exit(1);

    getline(infile1, filename2); //read the first line in data file

    infile2.open(filename2); //search and open the name of the file
    if(!infile2)exit(1);
}

//To read data from text file
//============================
void readFile(std::ifstream &infile, WTSlogType &wts_data){

    int dateTimeCounter = -1; //counter to check for dateTime data
    int speedCounter = -1; //counter to check for speed data
    int airTempCounter = -1; //counter to check for air temperature data
    int sunRadCounter = -1; //counter to check for solar radiation data

    //count the total of columns
    int colCount = 0;
    std::string headerStr; //to store the header line
    std::string column; //act as column buffer

    getline(infile, headerStr); //get header line
    std::stringstream ss1(headerStr);
    while(getline(ss1,column,',')){

        if(column == "WAST"){
            dateTimeCounter = colCount; //assign colCount if string matched "WAST"
        }
        if(column == "S"){
            speedCounter = colCount; //assign colCount if string matched "S"
        }
        if(column == "T"){
            airTempCounter = colCount; //assign colCount if string matched "T"
        }
        if(column == "SR"){
            sunRadCounter = colCount; //assign colCount if string matched "SR"
        }
        colCount++; //increment colCount
    }

    if(dateTimeCounter == -1){ //error message if dateTime column not found in file
        std::cout << "Error: WAST column not found!" << std::endl;
        return;
    }
    if(speedCounter == -1){ //error message if speed column not found in file
        std::cout << "Error: S column not found!" << std::endl;
        return;
    }
    if(airTempCounter == -1){ //error message if air temp column not found in file
        std::cout << "Error: T column not found!" << std::endl;
        return;
    }
    if(sunRadCounter == -1){ //error message if solar radiation column not found in file
        std::cout << "Error: SR column not found!" << std::endl;
        return;
    }

    std::string line; //buffer for reading line in file
    while(getline(infile, line)){

        std::stringstream ss2(line); //to stream the line again
        std::string token; //act as token or string buffer
        int count = 0;
        WTSType record; //temporary WTSType struct

        while(getline(ss2,token,',')){
            if(count == dateTimeCounter){ //if the current count same as dateTime counter

                std::stringstream dt(token); //stream the token again

                std::string dayStr; //container for day
                std::string monthStr; //container for month
                std::string yearStr; //container for year
                std::string hourStr; //container for hour
                std::string minuteStr; //container for minute

                getline(dt,dayStr,'/'); //read day until '/'
                getline(dt,monthStr,'/'); //read month until '/'
                getline(dt,yearStr,' '); //read year until ' '
                getline(dt,hourStr,':'); //read hour until ':'
                getline(dt,minuteStr,','); //read minute until ','

                int dayInt = std::stoi(dayStr); //convert string to integer
                int monthInt = std::stoi(monthStr); //convert string to integer
                int yearInt = std::stoi(yearStr); //convert string to integer
                int hourInt = std::stoi(hourStr); //convert string to integer
                int minuteInt = std::stoi(minuteStr); //convert string to integer

                record.d.SetDay(dayInt); //set day value in record
                record.d.SetMonth(monthInt); //set month value in record
                record.d.SetYear(yearInt); //set year value in record
                record.t.SetHour(hourInt); //set hour value in record
                record.t.SetMinute(minuteInt); //set minute value in record

            }
            if(count == speedCounter){ //if current count equal to speedCounter value
                if(!token.empty() && token != "NA")
                    record.speed = std::stof(token);//set speed value in record
                else
                    record.speed = 0;
            }
            if(count == airTempCounter){//if current count equal to airTempCounter value
                if(!token.empty() && token != "NA")
                    record.temp = std::stof(token);//set temp value in record
                else
                    record.temp = 0;
            }
            if(count == sunRadCounter){ //if current count equal to sunRadCounter value
                if(!token.empty() && token != "NA"){
                    float sunR;
                    sunR = std::stof(token); //convert from string to float
                    record.sunRad = (sunR/6)/1000; //set sunRad value in record
                }else
                    record.sunRad = 0;
            }
            count++; //increment the count
        }
        wts_data.addValue(record); //push back the record into wts_data vector
    }
}

//calculate sum
//============================
template <class T>
T calculateSum(Vector<T> &vec){
    T sum = 0;
    for(int i = 0; i < vec.getSize(); i++){
        sum += (vec[i]);
    }
    return sum;
}


//calculate mean
//============================
template <class T>
T calculateMean(Vector<T> &vec){
    T sum = 0;
    for(int i = 0; i < vec.getSize(); i++){
        sum += (vec[i]);
    }
    return round((sum/vec.getSize())*10)/10;
}

//calculate standard deviation
//============================
template <class T>
T calculateSD(Vector<T> &vec){
    T mean = calculateMean(vec);

    T sum = 0;
    for(int i = 0; i < vec.getSize(); i++){
        sum += (vec[i] - mean)*(vec[i] - mean);
    }
    return round((std::sqrt(sum / (vec.getSize() -1)))*10)/10;
}

//print menu
//============================
void printMenu(){
    std::cout << "\n\n==================================\n";
    std::cout << "\t\tMENU\n";
    std::cout << "==================================\n";
    std::cout << "1. Print mean and sd of wind speed.\n";
    std::cout << "2. Print mean and sd of ambient air temperature.\n";
    std::cout << "3. Print total of solar radiation.\n";
    std::cout << "4. Print mean of wind speed/air temperature and total solar radiation.\n";
    std::cout << "5. Exit program\n";
}

//perform switch case
//============================
void switchCases(WTSlogType &wts_data){
    int option;

    do{
        printMenu();
        std::cout << "\nPlease enter an option(1-5):\n";
        std::cin >> option;

        switch(option){
        case 1:
            switchCase1(wts_data);
            break;
        case 2:
            switchCase2(wts_data);
            break;
        case 3:
            switchCase3(wts_data);
            break;
        case 4:
            switchCase4(wts_data);
            break;
        case 5:
            switchCase5(wts_data);
            break;
        default:
            defaultSC();
        }
    }while(option != 5);
}

//switch case 1
//============================
void switchCase1(WTSlogType &wts_data){

    int monthInput;
    int yearInput;
    std::string mString[12] = {"January","February","March","April","May","June",
                            "July","August","September","October","November","December"};
    Vector<float> speed(N);

    do{
        std::cout << "\nPlease enter a month [1-12]: " << std::endl;
        std::cin >> monthInput;

        if(monthInput < 1 || monthInput > 12){
            std::cout << "\nError: Please enter a number from 1-12." << std::endl;
        }
    }while(monthInput < 1 || monthInput > 12);

    std::cout << "Please enter a year: " << std::endl;
    std::cin >> yearInput;

    std::string monthStr = mString[monthInput - 1];
    for(int i = 0; i < wts_data.getSize(); i++){
        if(wts_data[i].d.GetYear() == yearInput){
            if(wts_data[i].d.GetMonth() == monthStr){
                speed.addValue(wts_data[i].speed);
            }
        }
    }

    if(speed.getSize() == 0){
        std::cout << "\n\n" << monthStr << " " << yearInput << ": "
                << "No Data" << std::endl;
        return;
    }

    float mean = calculateMean(speed)*3.6;
    float sd = calculateSD(speed)*3.6;

    std::cout << "\n\n" << monthStr << " " << yearInput << ":" << std::endl;
    std::cout << "Average speed: " << mean << " km/h" << std::endl;
    std::cout << "Sample stdev: " << sd << std::endl;
}

//switch case 2
//============================
void switchCase2(WTSlogType &wts_data){

    int yearInput;
    std::string mString[12] = {"January","February","March","April","May","June",
                            "July","August","September","October","November","December"};
    std::cout << "Please enter a year: " << std::endl;
    std::cin >> yearInput;

    Vector<Vector<float>> monthVec(12);

    for(int i = 0; i < wts_data.getSize(); i++){
        if(wts_data[i].d.GetYear() == yearInput){
            for(int m = 0; m < 12; m++){
                if(wts_data[i].d.GetMonth() == mString[m]){
                    monthVec[m].addValue(wts_data[i].temp);
                    break;
                }
            }
        }
    }

    std::cout << "\n\n" << yearInput << std::endl;
    for(int n = 0; n < 12; n++){
        if(monthVec[n].getSize() > 0){
            float mean = calculateMean(monthVec[n]);
            float sd = calculateSD(monthVec[n]);
            std::cout << mString[n] << ": average: " << mean
                    << " degrees C, stdev: " << sd << std::endl;
        }
        else{
            std::cout << mString[n] << ": No Data" << std::endl;
        }
    }
}

//switch case 3
//============================
void switchCase3(WTSlogType &wts_data){

    int yearInput;
    std::cout << "Please enter a year: " << std::endl;
    std::cin >> yearInput;

    Vector<Vector<float>> monthVec(12);
    std::string mString[12] = {"January","February","March","April","May","June",
                            "July","August","September","October","November","December"};
    for(int i = 0; i < wts_data.getSize(); i++){
        if(wts_data[i].d.GetYear() == yearInput){
            for(int m = 0; m < 12; m++){
                if(wts_data[i].d.GetMonth() == mString[m] &&
                   wts_data[i].sunRad >= 0.01666){
                    monthVec[m].addValue(wts_data[i].sunRad);
                    break;
                }
            }
        }
    }

    std::cout << "\n\n" << yearInput << std::endl;
    for(int n = 0; n < 12; n++){
        if(monthVec[n].getSize() > 0){
            float sum = calculateSum(monthVec[n]);
            std::cout << mString[n] << ": " << sum << " kWh/m2" << std::endl;
        }
        else{
            std::cout << mString[n] << ": No Data" << std::endl;
        }
    }
}

//switch case 4
//============================
void switchCase4(WTSlogType &wts_data){
    int yearInput;

    std::cout << "Please enter a year: " << std::endl;
    std::cin >> yearInput;

    Vector<Vector<float>> monthVecSpeed(12);
    Vector<Vector<float>> monthVecTemp(12);
    Vector<Vector<float>> monthVecSunRad(12);

    std::string mString[12] = {"January","February","March","April","May","June",
                            "July","August","September","October","November","December"};
    for(int i = 0; i < wts_data.getSize(); i++){
        if(wts_data[i].d.GetYear() == yearInput){
            for(int m = 0; m < 12; m++){
                if(wts_data[i].d.GetMonth() == mString[m]){
                    monthVecSpeed[m].addValue(wts_data[i].speed);
                    monthVecTemp[m].addValue(wts_data[i].temp);
                    if(wts_data[i].sunRad >= 0.01666)
                        monthVecSunRad[m].addValue(wts_data[i].sunRad);
                    break;
                }
            }
        }
    }
    bool noYearData = true;
    for(int j = 0; j < 12; j++){
        if(monthVecSpeed[j].getSize() > 0)
            noYearData = false;
    }

    // Open file for writing
    std::ofstream outFile("WindTempSolar.csv");
    if (!outFile.is_open()) {
        std::cerr << "Error: Could not open WindTempSolar.csv for writing!" << std::endl;
        return;
    }


    if (noYearData) {
        std::cout << "\n\n" << yearInput << std::endl;
        std::cout << "No Data" << std::endl;

        outFile << yearInput << ",No Data,,,,,\n";
    } else {
        std::cout << "\n\n" << yearInput << std::endl;

        outFile << yearInput << "\n";
        for (int n = 0; n < 12; n++) {
            if (monthVecSpeed[n].getSize() > 0) {
                float mean_speed = round(calculateMean(monthVecSpeed[n]) * 36)/10;
                float mean_temp  = calculateMean(monthVecTemp[n]);
                float sum_sunRad = round(calculateSum(monthVecSunRad[n])*10)/10;
                float sd_speed   = round(calculateSD(monthVecSpeed[n]) * 36)/10;
                float sd_temp    = round(calculateSD(monthVecTemp[n])*10)/10;

                // Print to console
                std::cout << mString[n] << "," << mean_speed << "(" << sd_speed << "),"
                          << mean_temp << "(" << sd_temp << ")," << sum_sunRad << std::endl;

                // Write to CSV
                outFile << mString[n] << ","
                        << mean_speed << "," << sd_speed << ","
                        << mean_temp << "," << sd_temp << ","
                        << sum_sunRad << "\n";
            } else {
                std::cout << mString[n] << "," << "No Data" << std::endl;
                outFile << mString[n] << "," << "No Data\n";
            }
        }
    }

    outFile.close();
    std::cout << "\nData successfully written to WindTempSolar.csv\n";
}

//switch case 5
//============================
void switchCase5(WTSlogType &wts_data){
    std::cout << "Exiting the program...\n";
    std::cout << "Program exit successfully...\n";
    exit(0);
}

//default switch case
//============================
void defaultSC(){
    std::cout << "\nError: Invalid selection.\n";
    std::cout << "Please enter a valid option 1-5.\n";
}
