// DATE.CPP - Date class implementation

#include "date.h"

#include <iostream>
#include <string.h>

Date::Date(){
    day = 1;
    month = 1;
    year = 2025;
}

Date::Date(int d, int m, int y){
    day = d;
    month = m;
    year = y;
}

int Date::GetDay() const{
    return day;
}

std::string Date::GetMonth() const{
    std::string mString[] = {"January","February","March","April",
                            "May","June","July","August","September",
                            "October","November","December"};
    return mString[month - 1];
}

int Date::GetYear() const{
    return year;
}

void Date::SetDay(int d){
    day = d;
}

void Date::SetMonth(int m){
    month = m;
}

void Date::SetYear(int y){
    year = y;
}

std::istream &operator >> (std::istream &is, Date &dt){
    std::string dStr;
    std::string mStr;
    std::string yStr;

    int dInt;
    int mInt;
    int yInt;

    getline(is, dStr, '/');
    getline(is, mStr, '/');
    getline(is, yStr, ' ');

    dInt = std::stoi(dStr);
    mInt = std::stoi(mStr);
    yInt = std::stoi(yStr);

    dt.SetDay(dInt);
    dt.SetMonth(mInt);
    dt.SetYear(yInt);

    return is;
}

std::ostream &operator << (std::ostream &os, const Date &dt){
    os << dt.GetDay()
        << "/" << dt.GetMonth()
        << "/" << dt.GetYear() << " ";
    return os;
}


