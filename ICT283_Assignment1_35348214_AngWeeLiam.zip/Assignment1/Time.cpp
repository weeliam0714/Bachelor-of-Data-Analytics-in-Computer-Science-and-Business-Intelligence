// TIME.CPP - Time class implementation

#include "time.h"

#include <iostream>
#include <string.h>

Time::Time(){
    hour = 0;
    minute = 0;
}

Time::Time(int h, int m){
    hour = h;
    minute = m;
}


std::string Time::GetTime() const{
    return Time::GetHour() + ":" + Time::GetMinute();
}


std::string Time::GetHour() const{
    std::string hStr[24] = {"00","01","02","03","04","05",
                        "06","07","08","09","10","11",
                        "12","13","14","15","16","17",
                        "18","19","20","21","22","23"};
    return hStr[hour];
}

std::string Time::GetMinute() const{
    std::string mStr[10] = {"00","01","02","03","04",
                        "05","06","07","08","09"};
    if(minute < 10){
        return mStr[minute];
    }
    else{
        return std::to_string(minute);
    }
}

void Time::SetHour(int h){
    hour = h;
}

void Time::SetMinute(int m){
    minute = m;
}


void Time::SetTime(int h, int m){
    hour = h;
    minute = m;
}


std::istream &operator >> (std::istream &is, Time &T){
    std::string hStr;
    std::string mStr;

    int hInt;
    int mInt;

    getline(is, hStr, ':');
    getline(is, mStr, ',');

    hInt = std::stoi(hStr);
    mInt = std::stoi(mStr);

    T.SetHour(hInt);
    T.SetMinute(mInt);

    return is;
}

std::ostream &operator << (std::ostream &os, const Time &T){
    os << T.GetTime();
    return os;
}
