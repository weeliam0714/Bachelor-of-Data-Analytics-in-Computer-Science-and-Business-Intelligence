// TIME.H - Time class definition/interface
// author Ang


#ifndef TIME_H
#define TIME_H

#include <string>
#include <iostream>


	/**
	 * @class Time
	 * @brief  Manages Time data such as hour and minute in 24hr format.
	 *
	 * @author Ang Wee Liam
	 * @version 01.01
	 * @date 27/09/2025
	 *
	 * @todo To store Time details for Wind_Data use later.
	 *
	 */

class Time{
public:

    /// default constructor for Time
    Time();

    /// constructor with parameter for Time
    Time(int h, int m);

        /**
        * @brief  Get Time details
        *
        * This function will return the Time as string.
        *
        * @return std::string
        */
    std::string GetTime() const;

        /**
        * @brief  Get hour details
        *
        * This function will return the Time hour as string.
        *
        * @return std::string
        */
    std::string GetHour() const;

        /**
        * @brief  Get minute details
        *
        * This function will return the Time minute as string.
        *
        * @return std::string
        */
    std::string GetMinute() const;

        /**
        * @brief  Set Time hour details
        *
        * This function can be used to set the hour in Time object.
        *
        * @param  h - hour of the Time
        * @return void
        */
    void SetHour(int h);

        /**
        * @brief  Set Time minute details
        *
        * This function can be used to set the minute in Time object.
        *
        * @param  m - minute of the Time
        * @return void
        */
    void SetMinute(int m);

        /**
        * @brief  Set Time details
        *
        * This function can be used to set the hour and minute in Time object.
        *
        * @param  h - hour of the Time
        * @param  m - minute of the Time
        * @return void
        */
    void SetTime(int h, int m);

private:

    /// variable for Time hour
    int hour;

    /// variable for Time minute
    int minute;

};

/// ostream operator for Date
std::ostream &operator << (std::ostream &os, const Time &T);

/// istream operator for Date
std::istream &operator >> (std::istream &is, Time &T);

#endif // DATE_H

