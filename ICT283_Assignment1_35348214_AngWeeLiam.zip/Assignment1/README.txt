For assignment 1, read only one data file.  You MUST test with each file, as the columns have different order.

The data file must reside in this "data" folder.

Declare the file name data_source.txt in main(). 

main() routine must show the high level algorithm implementation. So the following must be crystal clear in main()

input  - where it is from

processing - high level processing steps (no detail, just calls to routines)

output - where output is going to go