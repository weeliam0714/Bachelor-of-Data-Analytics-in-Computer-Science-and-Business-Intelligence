// VECTOR.H - Vector class implementation/ interface

#ifndef VECTOR_H
#define VECTOR_H

#include <iostream>

/**
 * @class Vector class
 * @brief  Template class for a Vector that able to store different data type.
 *
 * @author Ang Wee Liam
 * @version 01.01
 * @date 08/10/2025
 *
 * @todo To act as a template for Vector and act almost like std::vector
 *
 */
template <class T>
class Vector{
public:

    ///default constructor
    Vector();
    ///constructor with  parameter
    Vector(int n);
    ///destructor
    ~Vector();

        /**
        * @brief  add Value into the Vector
        *
        * This function will insert the value into the Vector.
        *
        * @param  value - the value to be add into Vector
        * @return void
        */
    void addValue(T value);

        /**
        * @brief  to return the size (total number of element) in the Vector
        *
        * This function will return the total count of element in the Vector
        *
        * @return int
        */
    int getSize() const;

        /**
        * @brief  to return the capacity of the Vector
        *
        * This function will return the total capacity in the Vector.
        *
        * @return int
        */
    int getCapacity() const;

    ///[] operator for Vector
    T &operator [](int index) const;

    ///= operator for Vector
    Vector<T> &operator = (const Vector<T> &obj);

private:
        ///Vector pointer
    T* arr;
        ///Vector count of elements
    int size;
        ///Vector size/capacity
    int capacity;
};

//===============================================================================
//===============================================================================
///class implementation

///default constructor
template <class T>
Vector<T>::Vector(){
    size = 0;
    capacity = 0;
    arr = new T[capacity];
}

///constructor with parameter
template <class T>
Vector<T>::Vector(int n){
    size = 0;
    capacity = n;
    arr = new T[capacity];
}

///destructor
template <class T>
Vector<T>::~Vector(){
    delete[] arr;
}

///method to add value
template <class T>
void Vector<T>::addValue(T value){
    if(size == capacity){
        int newCap = 0;
        if(capacity == 0){
            newCap = 1;
        }
        else{
            newCap = capacity * 2;
        }

        T* newArr = new T[newCap];

        for(int i =0; i < size; i++){
            newArr[i] = arr[i];
        }

        delete[] arr;

        arr = newArr;
        capacity = newCap;
    }

    arr[size] = value;
    size++;
}

///method to get size
template <class T>
int Vector<T>::getSize() const{
    return size;
}

///method to get capacity
template <class T>
int Vector<T>::getCapacity() const{
    return capacity;
}

///[] operator definition
template <class T>
T &Vector<T>::operator [](int index) const{
    return arr[index];
}

///= operator definition
template <class T>
Vector<T> &Vector<T>::operator = (const Vector<T> &obj) {
    if(this == &obj){
        return *this;
    }

    delete[] arr;
    size = obj.size;
    capacity = obj.capacity;
    arr = new T[capacity];

    for(int i = 0; i<size; i++){
        arr[i] = obj.arr[i];
    }

    return *this;
}

#endif // VECTOR_H




