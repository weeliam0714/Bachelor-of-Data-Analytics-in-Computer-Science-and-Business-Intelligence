// DATE.H - Date class definition/interface
// author Ang


#ifndef DATE_H
#define DATE_H

#include <string>
#include <iostream>


	/**
	 * @class Date
	 * @brief  Manages Date data such as day, month and year.
	 *
	 * @author Ang Wee Liam
	 * @version 01.01
	 * @date 27/09/2025
	 *
	 * @todo To store Date details for Result use later.
	 *
	 */

class Date{
public:

    /// default constructor for Date
    Date();

    /// constructor with parameter for Date
    Date(int d, int m, int y);

        /**
        * @brief  Get Day details
        *
        * This function will return the Day as string.
        *
        * @return int
        */
    int GetDay() const;

        /**
        * @brief  Get Month details
        *
        * This function will return the Month as string.
        *
        * @return int
        */
    std::string GetMonth() const;

        /**
        * @brief  Get Year details
        *
        * This function will return the Year as string.
        *
        * @return std::string
        */
    int GetYear() const;

        /**
        * @brief  Set Date Day details
        *
        * This function can be used to set the Date Day in Date object.
        *
        * @param  d - Day of the Date
        * @return void
        */
    void SetDay(int d);

        /**
        * @brief  Set Date Month details
        *
        * This function can be used to set the Date Month in Date object.
        *
        * @param  m - Month of the Date
        * @return void
        */
    void SetMonth(int m);

        /**
        * @brief  Set Date Year details
        *
        * This function can be used to set the Date Year in Date object.
        *
        * @param  y - Year of the Date
        * @return void
        */
    void SetYear(int y);

private:

    /// variable for Date day
    int day;

    /// variable for Date month
    int month;

    /// variable for Date year
    int year;
};

/// ostream operator for Date
std::ostream &operator << (std::ostream &os, const Date &dt);

/// istream operator for Date
std::istream &operator >> (std::istream &is, Date &dt);

#endif // DATE_H
