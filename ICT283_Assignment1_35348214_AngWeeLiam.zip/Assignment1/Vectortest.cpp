#include <iostream>
#include <string>
#include <typeinfo>
#include "vector.h"

template <class T>
void TestMethod1(Vector<T> &vct);
template<class T>
void TestMethod2(Vector<T> &vct);
template<class T>
void TestMethod3(Vector<T> &vct);
template<class T>
void TestMethod4(Vector<T> &vct);
template<class T>
void TestMethod5(Vector<T> &vct);
template<class T>
void TestMethod6(Vector<T> &vct);
template<class T>
void TestMethod7(Vector<T> &vct);
template<class T>
void TestMethod8(Vector<T> &vct);
template<class T>
void TestMethod9(Vector<T> &vct);

int main(){

    Vector<float> floatVec{1};

    TestMethod1(floatVec);
    TestMethod2(floatVec);
    TestMethod3(floatVec);
    TestMethod4(floatVec);
    TestMethod5(floatVec);
    TestMethod6(floatVec);
    TestMethod7(floatVec);
    TestMethod8(floatVec);
    TestMethod9(floatVec);
}

template <class T>
void TestMethod1(Vector<T> &vct){
    std::cout << "\nTest Method 1: Check data type of floatVec\n";
    std::cout << "Result: " << typeid(T).name() << "\n\n";
}

template<class T>
void TestMethod2(Vector<T> &vct){
    std::cout << "Test Method 2: Check floatVec size\n";
    std::cout << "Result: " << vct.getSize() << "\n\n";
}

template<class T>
void TestMethod3(Vector<T> &vct){
    std::cout << "Test Method 3: Check floatVec capacity\n";
    std::cout << "Result: " << vct.getCapacity() << "\n\n";
}

template<class T>
void TestMethod4(Vector<T> &vct){
    std::cout << "Test Method 4: Add 1 value into floatVec\n";
    vct.addValue(5.5);
    std::cout << "Result: value successfully added into floatVec\n\n";
}

template<class T>
void TestMethod5(Vector<T> &vct){
    std::cout << "Test Method 5: Check floatVec value\n";
    std::cout << "Result: ";
    for(int i = 0; i < vct.getSize(); i++){
        std::cout << vct[i] << " ";
    }
    std::cout << "\n\n";
}

template<class T>
void TestMethod6(Vector<T> &vct){
    std::cout << "Test Method 6: Add 3 value into floatVec\n";
    vct.addValue(6.6);
    vct.addValue(7.7);
    vct.addValue(8.8);
    std::cout << "Result: value successfully added into floatVec\n\n";
}

template<class T>
void TestMethod7(Vector<T> &vct){
    std::cout << "Test Method 7: Check floatVec size after add new value\n";
    std::cout << "Result: " << vct.getSize() << "\n\n";
}

template<class T>
void TestMethod8(Vector<T> &vct){
    std::cout << "Test Method 8: Check floatVec capacity after add new value\n";
    std::cout << "Result: " << vct.getCapacity() << "\n\n";
}

template<class T>
void TestMethod9(Vector<T> &vct){
    std::cout << "Test Method 9: Check floatVec value\n";
    std::cout << "Result: ";
    for(int i = 0; i < vct.getSize(); i++){
        std::cout << vct[i] << "  " ;
    }
    std::cout << "\n\n";
}

